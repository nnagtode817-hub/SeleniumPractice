package Practice280426;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Nykka {

	WebDriver driver;
	
	@BeforeTest
	public void launch() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	    driver.get("https://www.nykaa.com/");
	    WebDriverManager.chromedriver().clearDriverCache().setup();
	}
   /* @Test
    public void sign() {
    	driver.findElement(By.xpath("//button[@aria-label='Sign in']")).click();
    	driver.findElement(By.xpath("//button[text()='Sign in with Mobile / Email']")).click();
        driver.findElement(By.xpath("//span[text()='Mobile Number']")).click();
    	driver.findElement(By.xpath("//input[@label='Mobile Number']")).sendKeys("7972299279");
    	driver.findElement(By.xpath("//button[text()='Get OTP']")).click();
    	driver.navigate().to("https://www.nykaa.com/");
    }
    */
    /*	@Test
    	public void search() {
    	WebElement search  = driver.findElement(By.xpath("//input[@placeholder='Search on Nykaa']"));
    	search.click();
    	search.sendKeys("Hair mask");
    	List<WebElement> auto = driver.findElement("")
    		
    	}
        */
    

	
	
	//choose category
         @Test
         public void sel() throws InterruptedException {
        	 Actions action = new Actions(driver);
        	 WebElement hair = driver.findElement(By.xpath("//a[text()='hair']"));
        	 action.moveToElement(hair).perform();
        	 WebElement option = driver.findElement(By.xpath("//a[@href='/hair-care/hair/hair-creams-masks/c/2041?ptype=lst&id=2041&root=nav_3&dir=desc&order=popularity']"));
        	 option.click();
        	 WebElement ch = driver.findElement(By.xpath("//img[@src='https://images-static.nykaa.com/uploads/40ce89ff-04aa-498c-b2ba-d285d1912a2e.jpg?tr=cm-pad_resize,w-300']"));
        	 ch.click();
         
    //choose a product
        	 
        //	 JavascriptExecutor js = (JavascriptExecutor)driver;   
        	 
        	 //scroll down
        	 //js.executeScript("window.scrollBy(0,2000)");
        	 
        	 
        	 // now wait for element
        	// WebDriverWait wait =new WebDriverWait(driver, Duration.ofSeconds(10));
        	 WebElement pro = driver.findElement(By.xpath("//h2[contains(text(), 'Dove Peptide')]"));	 
        	 //js.executeScript("arguments[0].scrollIntoView(true);", pro);
        	 
        	 Actions action1= new Actions(driver);
        	 action1.moveToElement(pro).perform();
        	 
        	 
        	 //click add to bag
        	 WebElement add = driver.findElement(By.xpath("(//span[text()='Add to Bag'])[1]"));
        	 add.click();
        	 
         }
         





}


