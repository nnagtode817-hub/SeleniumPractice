  package Practice050526;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class globalSQA {
WebDriver driver;
	
	@BeforeTest  
	public void launch() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	    driver.get("https://www.globalsqa.com/demo-site/");
	}
    @Test
    //frames and windows
    public void frames() {
    	driver.navigate().to("https://www.globalsqa.com/demo-site/frames-and-windows/");
    	driver.findElement(By.xpath("//a[@href='#']//parent::*")).click();             
    	
    	   
    }
   

    	//slider
    	@Test
    	public void sliders() throws InterruptedException {
    		driver.navigate().to("https://www.globalsqa.com/demo-site/sliders/");
    		//switch to iframe
    		driver.switchTo().frame(driver.findElement(By.cssSelector(".demo-frame")));
    		
    		//Red slider
    		WebElement slider = driver.findElement(By.xpath("//div[@id='red']"));
    		//action to move slider
    		Actions action = new Actions(driver);
    		action.clickAndHold(slider).moveByOffset(50,0).release().perform();
    		
    		//green slider
    		WebElement slider2 = driver.findElement(By.xpath("//div[@id='green']"));
    		//action to move slider
    		Actions action2 = new Actions(driver);
    		action2.clickAndHold(slider2).moveByOffset(50,0).release().perform();
    	
    		//blue slider 
    		WebElement slider3 = driver.findElement(By.xpath("//div[@id='blue']"));
    		//action to move slider
    		Actions action3 = new Actions(driver);
    		action3.clickAndHold(slider3).moveByOffset(50,0).release().perform();
    	}
    	    @Test 
    		//range slider
    	    public void range() {
    		driver.navigate().to("https://www.globalsqa.com/demo-site/sliders/");
    	   WebElement rangeTab = driver.findElement(By.xpath("//li[@id='Range']"));
    	  ((JavascriptExecutor) driver).executeScript("arguments[0].click();", rangeTab); 
    	   //switch to iframe
    		driver.switchTo().frame(driver.findElement(By.cssSelector(".demo-frame")));
    		List<WebElement> sliders = driver.findElements(By.xpath("//span[contains(@class, 'ui-slider-handle')]"));
    		WebElement leftslider = sliders.get(0);
    		WebElement rightslider = sliders.get(1);
      	  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", leftslider); 
            Actions action = new Actions(driver);
            
            //left slider
            action.moveToElement(leftslider).clickAndHold().moveByOffset(50, 0).release().perform();
          //right slider
            action.moveToElement(rightslider).clickAndHold().moveByOffset(-50, 0).release().perform();
    	
    	}
    	
    	    @Test 
    		//step slider
    	    public void step() {
    		driver.navigate().to("https://www.globalsqa.com/demo-site/sliders/");
    	   WebElement stepTab = driver.findElement(By.xpath("//li[@id='Steps']"));
    	  ((JavascriptExecutor) driver).executeScript("arguments[0].click();", stepTab); 
    	   
    	  //switch to iframe
  		    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector(".demo-frame")));
    		
    	 // locate slider
    		WebElement slider = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(@class, 'ui-slider-handle')]")));
      	  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", slider); 

    		Actions action = new Actions(driver);
    	
    		action.moveToElement(slider).clickAndHold().moveByOffset(40, 0).release().perform();	
    	
    }

  //dropdown  	    
@Test
public void dropdown() {
	driver.navigate().to("https://www.globalsqa.com/demo-site/select-dropdown-menu/");
    WebElement dropdown = driver.findElement(By.tagName("Select"));
	Select country = new Select(dropdown);	
    country.selectByVisibleText("India");

}
   //    dialogue box
@Test
public void dialogue() {
	
	driver.navigate().to("https://www.globalsqa.com/demo-site/dialog-boxes/");
	//driver.switchTo().frame(0);
	//driver.findElement(By.xpath("//button[text()='Create new user']")).click();
	driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@class='demo-frame']")));
	driver.findElement(By.id("create-user")).click();
	driver.findElement(By.xpath("//button[text()='Create an account']")).click();
	driver.switchTo().defaultContent();
	//message box
	List<WebElement>  msg = driver.findElements(By.xpath("//ul[@class='resp-tabs-list ']//li"));
	System.out.println("size of list in header:" + msg.size());
	for(WebElement msg1:msg)
		
	{
		System.out.println("name in list in dialog box:" + msg1.getText());
		if(msg1.getText().contains("Message Box"))
		{
			msg1.click();
			break;
		}

    	    
    	    
    	    
	}  	    
    	    	    
}  	    
}