package Practice290426;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class automation {
	WebDriver driver;
	
	@BeforeTest  
	public void launch() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	driver.get("https://automationexercise.com/");
	}
	
	@Test
	public void signup() {
	//signup
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	
	WebElement sign = driver.findElement(By.xpath("//a[@href='/login']"));
	sign.click();
	WebElement name = driver.findElement(By.xpath("//input[@placeholder='Name']"));
	name.sendKeys("Nandini");
	WebElement mail= driver.findElement(By.xpath("//input[@data-qa='signup-email']"));
	mail.sendKeys("shubham6790@gmail.com");
	WebElement signUp= driver.findElement(By.xpath("//button[text()='Signup']"));
	signUp.click();

	// Enter details
	driver.findElement(By.xpath("//input[@id='id_gender2']")).click();
	driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Athang@1234");
	driver.findElement(null)
	
}
	
	
	
	
	
	
}